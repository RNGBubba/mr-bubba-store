import json
import tempfile
import unittest
from pathlib import Path

from log_explorer import export_redacted, filter_events, load_events, redact_event


class LogExplorerTests(unittest.TestCase):
    def test_loads_jsonl_and_normalizes_common_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "events.jsonl"
            path.write_text(json.dumps({"timestamp": "2026-09-15T12:00:00Z", "level": "ERROR", "trace_id": "t1", "message": "failed"}) + "\n")
            events = load_events(path)
        self.assertEqual(events[0]["severity"], "ERROR")
        self.assertEqual(events[0]["trace_id"], "t1")

    def test_loads_csv_logs(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "events.csv"
            path.write_text("time,level,request_id,message\n2026-09-15T12:00:00Z,INFO,r1,started\n")
            events = load_events(path)
        self.assertEqual(events[0]["severity"], "INFO")
        self.assertEqual(events[0]["trace_id"], "r1")

    def test_filters_by_trace_and_message_text(self):
        events = [
            {"severity": "ERROR", "trace_id": "a", "message": "database failed"},
            {"severity": "INFO", "trace_id": "a", "message": "started"},
            {"severity": "ERROR", "trace_id": "b", "message": "database failed"},
        ]
        result = filter_events(events, severity="ERROR", trace_id="a", contains="database")
        self.assertEqual(result, [events[0]])

    def test_redacts_secrets_and_exports_jsonl(self):
        event = {"message": "email a@b.example token=abc123", "nested": {"password": "secret"}}
        safe = redact_event(event)
        self.assertNotIn("abc123", json.dumps(safe))
        self.assertNotIn("a@b.example", json.dumps(safe))
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "safe.jsonl"
            export_redacted([event], out)
            self.assertEqual(len(out.read_text().splitlines()), 1)
            self.assertNotIn("abc123", out.read_text())

    def test_redacts_bearer_basic_and_quoted_secret_values(self):
        event = {"message": "Authorization: Bearer bearer-secret password=\"quoted-secret\" client_secret: plain-secret"}
        encoded = json.dumps(redact_event(event))
        for secret in ("bearer-secret", "quoted-secret", "plain-secret"):
            self.assertNotIn(secret, encoded)

    def test_filter_contains_uses_message_and_trace_id_is_case_insensitive(self):
        events = [{"message": "Connection failed", "trace_id": "Trace-A", "metadata": "database"}]
        self.assertEqual(filter_events(events, trace_id="trace-a", contains="failed"), events)
        self.assertEqual(filter_events(events, contains="database"), [])

    def test_export_rejects_overwriting_source_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "events.jsonl"
            source.write_text("{}\n")
            with self.assertRaises(ValueError):
                export_redacted([{}], source, source_path=source)


if __name__ == "__main__":
    unittest.main()
