"""Dependency-free local JSONL/CSV log explorer with conservative redaction."""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Iterable

_EMAIL = re.compile(r"\b[^\s@]+@[^\s@]+\.[^\s@]+\b")
_SECRET_ASSIGNMENT = re.compile(
    r"(?i)\b(?:password|passwd|secret|token|api[_ -]?key|authorization|"
    r"access[_ -]?token|client[_ -]?secret)\b\s*[:=]\s*"
    r"(?:(?:bearer|basic)\s+)?(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)"
)


def _first(record: dict[str, Any], names: tuple[str, ...]) -> str:
    for name in names:
        value = record.get(name)
        if value not in (None, ""):
            return str(value)
    return ""


def normalize_event(record: dict[str, Any]) -> dict[str, Any]:
    event = dict(record)
    event["timestamp"] = _first(record, ("timestamp", "time", "ts", "datetime"))
    event["severity"] = _first(record, ("severity", "level", "loglevel")).upper()
    event["trace_id"] = _first(record, ("trace_id", "traceId", "request_id", "requestId"))
    event["message"] = _first(record, ("message", "msg", "body"))
    return event


def load_events(path: str | Path) -> list[dict[str, Any]]:
    """Load JSONL or CSV records without executing or uploading file content."""
    path = Path(path)
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8") as handle:
            return [normalize_event(row) for row in csv.DictReader(handle)]
    events = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSON on line {line_number}") from exc
            if not isinstance(record, dict):
                raise ValueError(f"line {line_number} must contain a JSON object")
            events.append(normalize_event(record))
    return events


def filter_events(
    events: Iterable[dict[str, Any]], *, severity: str | None = None,
    trace_id: str | None = None, contains: str | None = None,
) -> list[dict[str, Any]]:
    severity = severity.upper() if severity else None
    needle = contains.lower() if contains else None
    result = []
    for event in events:
        if severity and event.get("severity", "").upper() != severity:
            continue
        if trace_id and event.get("trace_id", "").lower() != trace_id.lower():
            continue
        if needle and needle not in str(event.get("message", "")).lower():
            continue
        result.append(event)
    return result


def redact_value(value: Any, key: str = "") -> Any:
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if re.search(r"(?i)(password|passwd|token|secret|api[_ -]?key|authorization)", k) else redact_value(v, k)) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_value(item, key) for item in value]
    if isinstance(value, str):
        value = _SECRET_ASSIGNMENT.sub("[REDACTED_SECRET]", value)
        return _EMAIL.sub("[REDACTED_EMAIL]", value)
    return value


def redact_event(event: dict[str, Any]) -> dict[str, Any]:
    return redact_value(event)


def export_redacted(
    events: Iterable[dict[str, Any]], path: str | Path,
    *, source_path: str | Path | None = None,
) -> None:
    """Write candidate-redacted JSONL without overwriting the source file."""
    path = Path(path)
    if source_path is not None and path.expanduser().resolve() == Path(source_path).expanduser().resolve():
        raise ValueError("export path must differ from source path")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            for event in events:
                handle.write(json.dumps(redact_event(event), ensure_ascii=False, sort_keys=True) + "\n")
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description="Explore local JSONL/CSV logs")
    parser.add_argument("path")
    parser.add_argument("--severity")
    parser.add_argument("--trace-id")
    parser.add_argument("--contains")
    parser.add_argument("--export-redacted")
    args = parser.parse_args()
    events = filter_events(load_events(args.path), severity=args.severity, trace_id=args.trace_id, contains=args.contains)
    if args.export_redacted:
        export_redacted(events, args.export_redacted, source_path=args.path)
    print(json.dumps({"matched_events": len(events), "redacted_export": args.export_redacted}, indent=2))


if __name__ == "__main__":
    main()
