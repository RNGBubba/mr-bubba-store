# Offline Structured-Log Explorer — prototype

A local-only JSONL/CSV log utility for developers. It normalizes common
severity, timestamp, message, and trace/request-ID fields using these aliases:
`timestamp/time/ts/datetime`, `severity/level/loglevel`,
`trace_id/traceId/request_id/requestId`, and `message/msg/body`; filters events;
and exports a candidate-redacted JSONL subset.

## Run

```bash
python3 -m unittest -q test_log_explorer.py
python3 log_explorer.py sample.jsonl --severity ERROR --trace-id t-100 \
  --export-redacted /tmp/redacted-log.jsonl
```

The prototype does not upload files, execute log content, collect telemetry, or
connect to an observability service. It rejects an export path equal to the
source path and writes exports through a temporary file before replacement.
Treat log files as untrusted input. The redactor is assistance, not a
guarantee: inspect the output before sharing it, and never assume secrets or
personal data were fully removed.

## Validation boundary

This is a local prototype with synthetic fixtures. Competitor pricing indicates
that observability is a paid category, not that this product has demand. Do not
claim customers, downloads, or revenue until independently recorded. Stop the
experiment if the declared formats are unreliable or voluntary demo use does
not produce measurable interest within the defined test window.
