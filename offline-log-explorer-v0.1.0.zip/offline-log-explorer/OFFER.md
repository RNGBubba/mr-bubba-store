# Offline Structured-Log Explorer — Pilot Offer

## Buyer hypothesis

Developers or small teams who need to inspect JSONL/CSV logs on a machine where
sending source logs to a hosted observability service is undesirable or
unavailable.

## Fixed scope

- One machine and one operator
- JSONL, CSV, or both
- Normalize declared timestamp, severity, message, trace-ID, or request-ID fields
- Filter by severity, trace/request ID, and text
- Export a JSONL subset with conservative email/secret-pattern redaction
- Short local run guide and synthetic/redacted examples

## Price hypothesis

$15 one-time pilot. This is a price hypothesis, not evidence of willingness to
pay.

## Safety and privacy boundary

Processing remains local. Do not send passwords, access tokens, bank details,
private customer records, production logs, or other sensitive data. The
redactor is not guaranteed secret removal and is not a security, privacy, or
compliance assessment. The buyer must inspect every export before sharing it.

## Validation gate

Count only independently recorded inbound requests and verified payments. Do
not count page loads, synthetic demo runs, competitor prices, directory queues,
or unverified email. If no qualified inbound request or paid pilot appears
within the test window, stop or revise the offer rather than expanding scope.
